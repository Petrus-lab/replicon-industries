const express = require("express");
const cors = require("cors");
const fs = require("fs");
const { exec } = require("child_process");
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

app.post("/run", (req, res) => {
  const { action, targetPath, inputData, raw } = req.body;

  switch (action) {
    case "shell":
      if (!inputData?.trim()) {
        return res.json({ output: "❌ Shell command is empty." });
      }
      exec(inputData, (err, stdout, stderr) => {
        res.json({
          output: err ? `❌ Shell Error:\n${stderr}` : stdout,
        });
      });
      break;

    case "python":
      if (!inputData?.trim()) {
        return res.json({ output: "❌ Python code is empty." });
      }
      fs.writeFileSync("temp.py", inputData);
      exec("python temp.py", (err, stdout, stderr) => {
        fs.unlinkSync("temp.py");
        res.json({
          output: err ? `❌ Python Error:\n${stderr}` : stdout,
        });
      });
      break;

    case "read":
      if (!targetPath?.trim()) {
        return res.json({ output: "❌ File path is required to read." });
      }
      try {
        const content = fs.readFileSync(targetPath, "utf-8");
        res.json({ output: content });
      } catch (e) {
        res.json({ output: `❌ File Read Error:\n${e.message}` });
      }
      break;

    case "write":
      if (!targetPath?.trim()) {
        return res.json({ output: "❌ File path is required to write." });
      }
      if (!inputData?.trim()) {
        return res.json({ output: "❌ No content provided for write." });
      }
      try {
        fs.writeFileSync(targetPath, inputData);
        res.json({ output: "✅ File written successfully." });
      } catch (e) {
        res.json({ output: `❌ File Write Error:\n${e.message}` });
      }
      break;

    case "json":
      try {
        const block = JSON.parse(raw);
        res.json({ output: `🧾 Parsed JSON:\n${JSON.stringify(block, null, 2)}` });
      } catch (e) {
        res.json({ output: `❌ JSON Parse Error:\n${e.message}` });
      }
      break;

    default:
      res.json({ output: `❌ Unknown action: ${action}` });
  }
});

app.listen(PORT, () => {
  console.log(`🧠 Replicon Local AI Runner is live on http://localhost:${PORT}`);
});
